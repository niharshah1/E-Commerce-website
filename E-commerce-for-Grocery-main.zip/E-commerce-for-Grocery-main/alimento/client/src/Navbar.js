import React from 'react'
import Alimento from './Alimento'


function Navbar(props) {
  return (
    <div>
     


    </div>
  )
}



export default Navbar
