import React from 'react'
import PropTypes from 'prop-types'

function Recipes(props) {
  return (
    <div>Recipes</div>
  )
}

Recipes.propTypes = {}

export default Recipes
