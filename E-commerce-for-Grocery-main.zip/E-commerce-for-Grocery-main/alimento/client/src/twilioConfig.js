module.exports = {
    accountSid: 'ACe4965548ce605175ed68343e41df542e',
    authToken: '768cd60f278cca3d137745bb56ad5f0b',
    twilioPhoneNumber: '+12708177580',
  };