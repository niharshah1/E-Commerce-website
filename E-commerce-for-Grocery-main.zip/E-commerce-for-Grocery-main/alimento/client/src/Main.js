import React from "react";
import shop from "./Shop";
import Alimento from "./Alimento";
import Contact from "./Contact";
import Signup from "./Signup";


function Main() {
  return (
    <div>
<ul>
    <Link to="/">Home</Link>
</ul>
    </div>
  )
}


export default Main
